<?php
function erid($index)
{
  return "Error, index [$index] belum terdefinisi.";
}
