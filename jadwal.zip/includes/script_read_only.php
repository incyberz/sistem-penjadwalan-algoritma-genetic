<?php $read_only = 1; ?>
<script>
  $(function() {
    $('button').prop('disabled', 1);
    $('input').prop('disabled', 1);
  });
</script>