<?php
$arr_tb_master = ['ta', 'prodi', 'kurikulum', 'mk', 'kelas', 'dosen', 'ruang', 'user'];
