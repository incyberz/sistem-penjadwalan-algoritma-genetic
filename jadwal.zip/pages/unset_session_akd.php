<?php
unset($_SESSION['ta_aktif']);
unset($_SESSION['id_prodi']);
unset($_SESSION['id_shift']);
unset($_SESSION['semester']);
unset($_SESSION['counter']);
