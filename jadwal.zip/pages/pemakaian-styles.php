<style>
  .blok_pemakaian,
  .nama_hari {
    border: solid 2px #ccf;
  }

  .blok_pemakaian thead {
    border-bottom: solid 2px #ccf;

  }

  .nama_hari {
    background: yellow;
    margin: 30px 0 15px 0;
  }

  .ruang_terisi {
    background: yellow !important
  }

  .sesi_break {
    background: #ddd !important;
  }

  .filtered_ruang {
    color: blue !important;
    font-weight: bold !important;
  }
</style>