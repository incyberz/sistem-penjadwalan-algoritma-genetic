<style>
  .label_check_mhs {
    display: block;
    cursor: pointer;
    padding: 5px 10px;
    transition: .3s;
  }

  .label_check_mhs:hover {
    letter-spacing: .5px;
    background: yellow;
  }
</style>