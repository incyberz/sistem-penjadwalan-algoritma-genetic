<?php
include "$dotdot/includes/set_h2.php";
include "$dotdot/includes/div_alert.php";
set_h2('Lupa Password', div_alert('info', "Untuk saat ini jika lupa password, silahkan hubungi langsung Pihak Akademik atau Developer."));
