<?php
$_SESSION['fakultas'] = $_GET['fakultas'] ?? udef('fakultas');
jsurl('?');
